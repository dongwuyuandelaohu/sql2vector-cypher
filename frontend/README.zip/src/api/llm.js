import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:8000/api/llm',
  timeout: 10000,
});

export default {
  // 生成表描述接口
  generateTableDescriptions(database, tables = []) {
    return apiClient.get(`/database/${database}`, {
      params: { 
        database,
        tables: tables.length ? tables : undefined 
      }
    });
  },

  // 格式化向量项接口
  formatVectorItems(metadata) {
    return apiClient.post('/format-vector-items', {
      metadata
    });
  }
};