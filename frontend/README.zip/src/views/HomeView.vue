<template>
  <div>
    <h1>欢迎使用 Text2SQL 后端接口系统</h1>
    <p>请选择左侧导航栏中的功能开始操作。</p>
  </div>
</template>