<template>
  <div class="database-manager">
    <!-- 数据库连接设置 -->
    <el-card class="connection-form">
      <h3>数据库连接设置</h3>
      <el-form label-position="top">
        <el-form-item label="用户名">
          <el-input v-model="dbConfig.username" placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="dbConfig.password" type="password" placeholder="请输入密码" />
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input v-model="dbConfig.host" placeholder="请输入IP地址" />
        </el-form-item>
        <el-form-item label="端口">
          <el-input v-model="dbConfig.port" placeholder="请输入端口号" />
        </el-form-item>
        <el-button type="primary" @click="connectDatabase">连接</el-button>
      </el-form>
    </el-card>

    <!-- 主内容区 -->
    <div class="main-content">
      <!-- 第一列：数据库和表选择 -->
      <div class="content-column" style="width: 25%;">
        <el-card class="database-section">
          <h3>选择数据库</h3>
          <el-select 
            v-model="selectedDatabase" 
            placeholder="请选择数据库" 
            @change="loadTables"
            style="width: 100%;"
          >
            <el-option
              v-for="db in databases"
              :key="db"
              :label="db"
              :value="db"
            />
          </el-select>

          <h4 style="margin-top: 20px;">表名列表</h4>
          <el-menu 
            :default-active="selectedTable" 
            @select="handleTableSelect"
            style="border-right: none;"
          >
            <el-menu-item v-for="table in tables" :key="table" :index="table">
              {{ table }}
            </el-menu-item>
          </el-menu>
        </el-card>
      </div>

      <!-- 第二列：建表语句 -->
      <div class="content-column" style="width: 45%;">
        <el-card class="schema-view">
          <h4>建表语句</h4>
          <pre>{{ selectedSchema }}</pre>
        </el-card>
      </div>

      <!-- 第三列：操作按钮 -->
      <div class="content-column" style="width: 15%;">
        <el-card class="operation-buttons">
          <el-button 
            type="primary" 
            @click="generateTableDescription"
            style="margin-bottom: 15px; width: 100%;"
          >
            LLM生成描述
          </el-button>
          <el-button 
            type="primary" 
            @click="generateAndSaveKnowledgeBase"
            style="margin-bottom: 15px; width: 100%;"
          >
            生成知识库并保存
          </el-button>
          <el-upload
            action=""
            :auto-upload="false"
            :on-change="handleFileUpload"
            :show-file-list="false"
          >
            <el-button 
              type="primary" 
              style="width: 100%;"
            >
              生成向量库
            </el-button>
          </el-upload>
        </el-card>
      </div>

      <!-- 第四列：结果展示 -->
      <div class="content-column" style="width: 15%;">
        <el-card class="result-section">
          <h4>生成结果</h4>
          <pre>{{ tableDescriptionResult }}</pre>
          <el-button 
            v-if="tableDescriptionResult" 
            @click="saveAsText(tableDescriptionResult, 'table-description.txt')"
            style="margin-top: 10px; width: 100%;"
          >
            保存结果
          </el-button>
        </el-card>
      </div>
    </div>
  </div>
</template>

<script>
import llmApi from '@/api/llm' 
import databaseApi from '@/api/database'
export default {
  data() {
    return {
      dbConfig: {
        username: '',
        password: '',
        host: '',
        port: ''
      },
      databases: [],
      selectedDatabase: '',
      tables: [],
      selectedTable: '',
      selectedSchema: '',
      tableDescriptionResult: ''
    }
  },
  methods: {
    async connectDatabase() {
      if (!this.dbConfig.username || !this.dbConfig.host || !this.dbConfig.port) {
        this.$message.warning('请填写完整连接信息')
        return
      }
      try {
        const res = await databaseApi.listDatabases() // 假设你用了 axios
        this.databases = res.data
        this.$message.success('连接成功')
      } catch (e) {
        this.$message.error('连接失败，请检查配置')
      }
    },
    async loadTables() {
      if (!this.selectedDatabase) return
      try {
        const res = await databaseApi.listTables(this.selectedDatabase)
        this.tables = res.data
        if (res.data.length > 0) {
          this.selectedTable = res.data[0]
          this.loadSchema(this.selectedTable)
        }
      } catch (e) {
        this.$message.error('获取表列表失败')
      }
    },
    async loadSchema(tableName) {
      try {
        const res = await databaseApi.getAllSchemas(this.selectedDatabase)
        this.selectedSchema = res.data || ''
      } catch (e) {
        this.$message.error('获取建表语句失败')
      }
    },
    handleTableSelect(table) {
      this.selectedTable = table
      this.loadSchema(table)
    },
    async generateTableDescription() {
      if (!this.selectedDatabase || !this.selectedTable) {
        this.$message.warning('请选择数据库和表')
        return
      }
      try {
        const res = await llmApi.generateTableDescriptions({
          database: this.selectedDatabase,
          tables: [this.selectedTable]
        })
        this.tableDescriptionResult = JSON.stringify(res.data, null, 2)
        this.$message.success('表描述生成成功')
      } catch (e) {
        this.$message.error('生成表描述失败')
      }
    },
    async generateAndSaveKnowledgeBase() {
      if (!this.selectedDatabase) {
        this.$message.warning('请选择数据库')
        return
      }
      try {
        const res = await llmApi.formatVectorItems({
          database: this.selectedDatabase
        })
        this.saveAsJSON(res.data, 'knowledge-base.json')
        this.$message.success('知识库已保存')
      } catch (e) {
        this.$message.error('生成知识库失败')
      }
    },
    async handleFileUpload(file) {
      try {
        const reader = new FileReader()
        reader.onload = async (e) => {
          const content = e.target.result
          try {
            const res = await this.$axios.post('/api/format-vector-items', { metadata: JSON.parse(content) })
            this.tableDescriptionResult = JSON.stringify(res.data, null, 2)
            this.$message.success('向量库生成成功')
          } catch (e) {
            this.$message.error('处理文件内容失败')
          }
        }
        reader.readAsText(file.raw)
      } catch (e) {
        this.$message.error('文件读取失败')
      }
    },
    saveAsJSON(data, filename) {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = filename
      link.click()
    },
    saveAsText(data, filename) {
      const blob = new Blob([data], { type: 'text/plain' })
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = filename
      link.click()
    }
  }
}
</script>